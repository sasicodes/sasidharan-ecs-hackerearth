export const URL_PATH = {
  USER_LIST: "/",
  PLAY_AREA: "/play",
};
