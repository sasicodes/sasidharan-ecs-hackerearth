> Pseudo Frontend Application by Sasidharan

- I have used react to build this application
- Using axios for fetching REST APIs.


HOSTED URL  - https://sasi-pseudo-app.netlify.app/

Thanks,
Sasidharan K
9788564664
sasiddharan@gmail.com
